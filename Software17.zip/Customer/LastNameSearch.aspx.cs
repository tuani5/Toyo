﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Customer_NarrowSearch : System.Web.UI.Page
{
  
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Button1.Enabled = false;
        }
        else {
            Button1.Enabled = true;
        } 
    }
    protected void ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
    {
        Button1.Enabled = true;   
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        
    }
}