﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Maintenance_AddMaintService : System.Web.UI.Page
{
    DateTime thisDay = DateTime.Today;
    

    protected void Page_Load(object sender, EventArgs e)
    {
        string lvl = (string)Session["Level"];
        if (lvl == null)
        {
            Response.Redirect("~/LoginPage.aspx");
        }
        Label1.Text = ""; Label2.Text = "";
        DateLabel.Text = thisDay.ToString("MM-dd-yyyy");
    }

    protected void AddButton_Click(object sender, EventArgs e)
    {
        if (Page.IsValid)
        {
            string error = "";
            if (DropDownList1.SelectedIndex > 0)
            {
                string vehid = DropDownList1.SelectedItem.ToString().Trim();
                int mi = int.Parse(mileTextBox.Text);
                string today = DateLabel.Text;
                string sche = "";
                if (yesRadio.Checked) { sche= "yes"; } else if (noRadio.Checked) { sche = "no"; } else {sche = "n/a"; }
                string descrip = DescriptionTextBox.Text;
                MaintQuery.CreateMaint(vehid, mi, today, sche, descrip, out error);
                if (error == "")
                {
                    Label2.Text = vehid + " was Added to Maintenance History."; 
                }
                else
                {
                    Label2.Text = error;
                }
            }
            else
            {
                Label1.ForeColor = System.Drawing.Color.Red;
                Label1.Text = "Error: You need to select Vehicle Id";
            }
        }
        if (DropDownList1.SelectedIndex == 0)
        {
            Label1.ForeColor = System.Drawing.Color.Red;
            Label1.Text = "Error: You need to select Vehicle Id";
        }
    }
}