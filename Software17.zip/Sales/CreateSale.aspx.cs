﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Sales_CreateSale : System.Web.UI.Page
{
    DateTime thisDay = DateTime.Today;
    protected void Page_Load(object sender, EventArgs e)
    {
        string lvl = (string)Session["Level"];
        if (lvl == null)
        {
            Response.Redirect("~/LoginPage.aspx");
        }
        Label1.Text = "";
        Label2.Text = "";
        DateLabel.Text = thisDay.ToString("MM-dd-yyyy");   
    }

    protected void SaleButton_Click(object sender, EventArgs e)
    {
        if (Page.IsValid)
        {
            if (DropDownList1.SelectedIndex > 0 && DropDownList2.SelectedIndex > 0)
            {
                string cust_id = DropDownList1.SelectedItem.ToString(); //get customer id
                string Vin = DropDownList2.SelectedItem.ToString().Trim(); //get car id
                string xlast="", xfirst="";
                string xmake="", xmodel="", xyear="",today,saleper,  mant="",war="";
                today = thisDay.ToString("MM-dd-yyyy");
                decimal sprice=decimal.Parse(PriceTextBox.Text);
                saleper = UATextBox.Text.ToString();
                string chk_cust = "", chk_ivtry = "", chk_crea_sale = "", chk_delete_car="";
                int mi=0;
                Customer khach = CustomerQuery.GetCustomer(int.Parse(cust_id), out chk_cust);
                if (khach != null)
                {
                    xlast = khach.GetCustLast;//customer lastname
                    xfirst = khach.GetCustFirst;//customer firstname
                }
                Inventory carinf = InventoryQuery.GetInventory(int.Parse(Vin), out chk_ivtry);
                if(carinf != null)
                {
                    xmake = carinf.getMake.Trim(); //get make of car
                    xmodel = carinf.getModel.Trim(); //get model of car
                    xyear = carinf.getYear.ToString().Trim(); //get year of car
                    mant = carinf.getMain.Trim(); //mantenance
                    war = carinf.getWarranty.Trim();//warranty
                    mi = carinf.getMileage;
                }
                if (carinf != null && khach != null)
                {
                    SaleQuery.CreateSale(cust_id, xlast, xfirst, Vin, xmake, xmodel, xyear,today, sprice, saleper, mant,war, out chk_crea_sale);
                    if (chk_crea_sale == "")
                    {
                        //delete from inventory
                        InventoryQuery.DeleteInventory(out chk_delete_car, int.Parse(Vin));
                        if (chk_delete_car == "")
                        {
                            Label1.ForeColor = System.Drawing.Color.Green;
                            Label1.Text = "Sale was Created.";
                        }
                        else
                        {
                            Label2.Text = "1: " + chk_cust + " 2: " + chk_ivtry + " 3: " + chk_crea_sale + " 4: " + chk_delete_car;
                        }
                        //if maintenace
                        if (mant == "3 years" || mant == "4 years" )
                        {
                            MaintQuery.CreateMaint(Vin, mi, today, "n/a", "Delivery", out chk_crea_sale);
                        }
                    }
                }
                
            }
            else
            {
                Label1.ForeColor = System.Drawing.Color.Red;
                Label1.Text = "Error in Dropdownlist(s). You need to select both DropdownLists.";
            }   
        }
        if ( DropDownList1.SelectedIndex == 0 || DropDownList2.SelectedIndex == 0)
        {
            Label1.ForeColor = System.Drawing.Color.Red;
            Label1.Text = "Error in Dropdownlist(s). You need to select both DropdownLists.";
        }
    }
}