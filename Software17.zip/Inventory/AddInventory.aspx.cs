﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AddInventory : System.Web.UI.Page
{
    enum hopso { Auto, Manual }; //transmission
    enum moicu { New, Used };   //condition
    enum anti_brake { Standard, Optional }; //antilock brake
    enum s_indicator { Standard, Optional }; //service indicator
    enum frontsAB { Standard, Optional }; //front side air bag
    enum wheels { Alloy, Steel }; //wheels
    enum design { Leather, Cloth, seats }; //interior design
    enum audiosys { Sirius, DVD, player, radio }; //audio system
    enum conv { Keyless, entry, Cruise, control }; //convenience
    enum pack { Premium, Sport }; //extra package
    enum powSteer { Standard, Optional }; //power steering

    
    protected void Page_Load(object sender, EventArgs e)
    {
        string lvl = (string)Session["Level"];
        if (lvl == null)
        {
            Response.Redirect("~/LoginPage.aspx");
        }
        Label1.Text = "";

    }
  
    protected void AddButton_Click(object sender, EventArgs e)
    {

        if (Page.IsValid)
        {
            string cond, model, make, engine, trans, psteering, antibrake, serviceind, frontairbag, color, wheel, intdesign, audio, conven, maint, warranty, extra;
            int mile, year;
            decimal price;
            //condition 'a1'
            if (newRadio.Checked) { cond = moicu.New.ToString(); } else { cond = moicu.Used.ToString(); }
            //year 'b2'
            year = int.Parse(yearTextBox.Text);
            //make 'c3'
            make = makeTextBox.Text;
            //model 'd4'
            model = modelTextBox.Text;
            //price 'e5'
            price = decimal.Parse(priceTextBox.Text);
            //mile 'f6'
            mile = int.Parse(mileTextBox.Text);
            //color 'g7'
            color = colorDropDownList.SelectedValue.ToString();
            //engine 'h8'
            engine = engineDropDownList.SelectedValue.ToString();
            //transmission 'i9'
            if (autoRadioButton.Checked) { trans = hopso.Auto.ToString(); } else { trans = hopso.Manual.ToString(); }
            //anitilock brakes 'j10'
            if (antilockBrakeRadioButton.Checked) { antibrake = anti_brake.Standard.ToString(); } else { antibrake = anti_brake.Optional.ToString(); }
            //service indicator 'k11'
            if (serviceRadioButton.Checked) { serviceind = s_indicator.Standard.ToString(); } else { serviceind = s_indicator.Optional.ToString(); }
            //front side air bag 'l12'
            if (frontABRadioButton.Checked) { frontairbag = frontsAB.Standard.ToString(); } else { frontairbag = frontsAB.Optional.ToString(); }
            //wheels 'm13'
            if (alloyRadioButton.Checked) { wheel = wheels.Alloy.ToString(); } else { wheel = wheels.Steel.ToString(); }
            //interior design 'n14'
            if (leatherRadioButton.Checked) { intdesign = design.Leather.ToString() + " " + design.seats.ToString(); } else { intdesign = design.Cloth.ToString() + " " + design.seats.ToString(); }
            //audio system 'o15'
            if (siriusRadioButton.Checked) { audio = audiosys.Sirius.ToString() + " " + audiosys.radio.ToString(); } else { audio = audiosys.DVD.ToString() + " " + audiosys.player.ToString(); }
            //convenience 'p16'
            if (keylessRadioButton.Checked) { conven = conv.Keyless.ToString() + " " + conv.entry.ToString(); } else { conven = conv.Cruise.ToString() + " " + conv.control.ToString(); }
            //maintenence program 'q17'
            if (threeRadioButton.Checked) { maint = "3 years"; } else if (fourRadioButton.Checked) { maint = "4 years"; } else { maint = "n/a"; }
            //warranty 'r18'
            if (baRadioButton.Checked) { warranty = "3 years"; } else if (bonRadioButton.Checked) { warranty = "4 years"; } else { warranty = "n/a"; }
            //extra package 's19'
            if (premiumRadioButton.Checked) { extra = pack.Premium.ToString(); } else if (sportRadioButton.Checked) { extra = pack.Sport.ToString(); } else { extra ="n/a"; }
            //power steering 't20'
            if (powsteerRadioButton.Checked) { psteering = powSteer.Standard.ToString(); } else { psteering = powSteer.Optional.ToString(); }

            string outputmessage;
         
            InventoryQuery.AddInventory(cond,year,make,model,price,mile,color,engine,trans,antibrake,serviceind,frontairbag,wheel,intdesign,audio,conven,maint,warranty,extra,psteering, out outputmessage);
            //if error
            if (outputmessage.Length > 0)
            {
                Label1.ForeColor = System.Drawing.Color.Red;
                Label1.Text = outputmessage;
            }
            else
            {
                Label1.ForeColor = System.Drawing.Color.Green;
                Label1.Text = "Vehicle was added!";
            }
        }
 
    }
}