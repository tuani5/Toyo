﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MasterPageMech : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {


    }
    protected void DropDownListLogin_SelectedIndexChanged(object sender, EventArgs e)
    {
        int selectIndex = DropDownListLogin.SelectedIndex;
        if (selectIndex == 1)
        {
            Session.Abandon();
            Session.Contents.RemoveAll();
            Response.Redirect("~/LoginPage.aspx");
        }
    }
    protected void DropDownListMaint_SelectedIndexChanged(object sender, EventArgs e)
    {
        int selectIndex = DropDownListMaint.SelectedIndex;
        if (selectIndex == 1)
        {
            Response.Redirect("~/Maintenance/ViewMaintenance.aspx");
        }
        else if (selectIndex == 2)
        {
            Response.Redirect("~/Maintenance/ViewVehId.aspx");
        }
        else if (selectIndex == 3)
        {
            Response.Redirect("~/Maintenance/AddMaintService.aspx");
        }
    }
}
