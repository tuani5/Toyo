﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Order_CreateOrder : System.Web.UI.Page
{
    private decimal _retail;
    private string estDate;
    enum hopso { Auto, Manual }; //transmission
    enum moicu { New, Used };   //condition
    enum anti_brake { Standard, Optional }; //antilock brake
    enum s_indicator { Standard, Optional }; //service indicator
    enum frontsAB { Standard, Optional }; //front side air bag
    enum wheels { Alloy, Steel }; //wheels
    enum design { Leather, Cloth, seats }; //interior design
    enum audiosys { Sirius, DVD, player, radio }; //audio system
    enum conv { Keyless, entry, Cruise, control }; //convenience
    enum pack { Premium, Sport }; //extra package
    enum powSteer { Standard, Optional }; //power steering

    protected void Page_Load(object sender, EventArgs e)
    {
        string lvl = (string)Session["Level"];
        if (lvl == null)
        {
            Response.Redirect("~/LoginPage.aspx");
        }
        Label1.Text = "";
        DeliveryLabel.Text = "";
        PriceLabel.Text = "";
        ModelDropDownList_SelectedIndexChanged(sender, e);

    }
    protected void ModelDropDownList_SelectedIndexChanged(object sender, EventArgs e)
    {
        string outputmessage;
        string man_id = ModelDropDownList.SelectedValue.ToString();
        int _manKey;
        bool result = int.TryParse(man_id, out _manKey);
        if (result)
        {
            Manufacturer man = ManufactQuery.GetManufact(_manKey, out outputmessage);
            if (man != null)
            {
                _retail = man.getPrice; PriceLabel.Text = _retail.ToString();
                int aval = man.GetManAvail;
                //if available estimate delivery date
                if (aval > 0)
                {
                    estDate = EstimateDilivery(aval);
                    DeliveryLabel.Text = estDate;
                }
                else //not available
                {
                    estDate = "Back Order";
                    DeliveryLabel.Text = estDate;
                }

            }
        }
    }
    protected string EstimateDilivery(int _avail)
    {
        DateTime today = new DateTime();
        today = DateTime.Today;
        //weekend
        if (today.DayOfWeek == DayOfWeek.Saturday || today.DayOfWeek == DayOfWeek.Sunday)
        {
            today = today.AddDays(5);
        }
        else //weekday
        {
            today = today.AddDays(7);
        }
        return today.ToString("MM-dd-yyyy");
    }
    protected void CreateOrderButton_Click(object sender, EventArgs e)
    {
        //both dropdownlist selected
        if (ModelDropDownList.SelectedIndex > 0 && DropDownList1.SelectedIndex > 0)
        {
            string outputmessage;
            string man_id = ModelDropDownList.SelectedValue.ToString();
            int _manKey;
            bool result = int.TryParse(man_id, out _manKey);
            string xmodel = ModelDropDownList.SelectedItem.ToString().Trim();
            string xmake = "", xengine = "", xtran = "", xpow = "", antibrake = "", serviceind = "", frontairbag = "", color = "", wheel = "", intdesign = "", audio = "", conven = "", extra = ""; ;
            int xyear;
            string xcust = DropDownList1.SelectedItem.ToString().Trim();
            if (result)
            {
                Manufacturer man = ManufactQuery.GetManufact(_manKey, out outputmessage);
                if (outputmessage == "")
                {
                    xmake = man.getMake;
                    xyear = man.getYear;
                    xengine = engineDropDownList.SelectedValue.ToString().Trim();
                    //trans
                    if (autoRadioButton.Checked) { xtran = hopso.Auto.ToString(); } else { xtran = hopso.Manual.ToString(); }
                    //power steering
                    if (powsteerRadioButton.Checked) { xpow = powSteer.Standard.ToString(); } else { xpow = powSteer.Optional.ToString(); }
                    //anti lock brake
                    if (antilockBrakeRadioButton.Checked) { antibrake = anti_brake.Standard.ToString(); } else {antibrake = anti_brake.Optional.ToString();}
                    
                    
                        
                        //service indicator
                        if (serviceRadioButton.Checked) { serviceind = s_indicator.Standard.ToString(); } else { serviceind = s_indicator.Optional.ToString(); }
                        //Front Side AB
                        if (frontABRadioButton.Checked) { frontairbag = frontsAB.Standard.ToString(); } else { frontairbag = frontsAB.Optional.ToString(); }
                        //color
                        color = colorDropDownList.SelectedValue.ToString();
                        //wheel
                        if (alloyRadioButton.Checked) { wheel = wheels.Alloy.ToString(); } else { wheel = wheels.Steel.ToString(); }
                        //interior des
                        if (leatherRadioButton.Checked) { intdesign = design.Leather.ToString() + " " + design.seats.ToString(); } else { intdesign = design.Cloth.ToString() + " " + design.seats.ToString(); }
                        //audio system
                        if (siriusRadioButton.Checked) { audio = audiosys.Sirius.ToString() + " " + audiosys.radio.ToString(); } else { audio = audiosys.DVD.ToString() + " " + audiosys.player.ToString(); }
                        //convenience
                        if (keylessRadioButton.Checked) { conven = conv.Keyless.ToString() + " " + conv.entry.ToString(); } else { conven = conv.Cruise.ToString() + " " + conv.control.ToString(); }
                        //extra package
                        if (premiumRadioButton.Checked) { extra = pack.Premium.ToString(); } else if (sportRadioButton.Checked) { extra = pack.Sport.ToString(); } else { extra = "n/a"; }


                        BuyQuery.CreateOrder(_retail, xmodel, xmake, xyear, xengine, xtran, xpow, antibrake, serviceind, frontairbag, color, wheel, intdesign, audio, conven, extra, xcust, estDate, out outputmessage);


                        if (outputmessage == "")
                        {
                            Label1.ForeColor = System.Drawing.Color.Green;
                            Label1.Text = "Order was Created.";
                        }
                        else
                        {
                            Label1.ForeColor = System.Drawing.Color.Red;
                            Label1.Text = outputmessage;
                        }                    
                }
            }
            else
            {
                Label1.ForeColor = System.Drawing.Color.Red;
                Label1.Text = "Error:  You must pick Model and Customer Id.";
            }

        }
        else
        {
            Label1.ForeColor = System.Drawing.Color.Red;
            Label1.Text = "Error:  You must pick Model and Customer Id.";
        }
    }
}