﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Buy
/// </summary>
public class Buy
{
    private int _orderkey;
    private decimal _price;
    private string _model;
	public Buy(SqlDataReader rdr)
	{
        _orderkey = (int)rdr["Order_No"];
        _price = (decimal)rdr["Price"];
        _model = (string)rdr["Model"];

	}
    public int getOrderId
    {
        get { return _orderkey; }
    }
    public decimal getPrice
    {
        get { return _price; }

    }
    public string getModel
    {
        get { return _model; }
    }
	
}