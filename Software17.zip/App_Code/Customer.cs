﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Customer
/// </summary>
public class Customer
{
    private int custkey;
    private string lastN;
    private string firstN;
	public Customer(SqlDataReader rdr)
	{
        custkey = (int)rdr["Id"];
        lastN = (string)rdr["Last_Name"];
        firstN = (string)rdr["First_Name"];
	}
    public int GetCustId
    {
        get { return custkey; }
    }
    public string GetCustLast
    {
        get { return lastN; }
    }
    public string GetCustFirst
    {
        get { return firstN; }
    }
}