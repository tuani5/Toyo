﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;

/// <summary>
/// Summary description for CustomerQuery
/// </summary>
public static class CustomerQuery
{
    public static Customer GetCustomer(int user_key, out string message)
    {
        SqlDataReader rdr = null;
        SqlConnection cn = null;
        Customer cst = null;

        try
        {
            cn = Setup_Connection();
            rdr = Get_Customer(cn, user_key);  // Perform the query
            message = "";
            if (rdr.Read())
            {
                cst = new Customer(rdr);
            }
            else
            {
                message = " Error in Customer.";
            }

        }
        catch (Exception ex)
        {
            message = " Error" + ex.Message;
        }
        finally
        {
            if (rdr != null)
            {
                rdr.Close();
            }

            if (cn != null)
            {
                cn.Close();
            }
        }
        return cst;
    }

    public static SqlConnection Setup_Connection()
    {
        String connection_string =
            WebConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;

        SqlConnection cn = new SqlConnection(connection_string);

        cn.Open();
        return cn;

    }

    public static SqlDataReader Get_Customer(SqlConnection cn, int search)
    {
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "SELECT * FROM Addresses WHERE Id=@user";
        cmd.Parameters.AddWithValue("@user", search);
        cmd.Connection = cn;
        return cmd.ExecuteReader();
    }
}