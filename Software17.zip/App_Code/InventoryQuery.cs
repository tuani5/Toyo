﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Web.Configuration;
/// <summary>
/// Summary description for InventoryQuery
/// </summary>
public class InventoryQuery
{
	public static Inventory GetInventory(int id,out string message)
	{
        SqlDataReader rdr = null;
        SqlConnection cn = null;
        Inventory myinventory = null;

        try
        {
            cn = Setup_Connection();
            rdr = Get_Reader(cn,id);  // Perform the query
            message = "";
            if (rdr.Read())
            {
                myinventory = new Inventory(rdr);
            }
            else
            {
                message = " Error in GetInventory.";
            }

        }
        catch (Exception ex)
        {
            message = " Error" + ex.Message;
        }
        finally
        {
            if (rdr != null)
            {
                rdr.Close();
            }

            if (cn != null)
            {
                cn.Close();
            }
        }
        return myinventory;
	}
    public static SqlConnection Setup_Connection()
    {
        String connection_string =
            WebConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;

        SqlConnection cn = new SqlConnection(connection_string);

        cn.Open();
        return cn;

    }

    public static SqlDataReader Get_Reader(SqlConnection cn,int id)
    {
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "SELECT * FROM Inventory WHERE CarId=@user";
        cmd.Parameters.AddWithValue("@user", id);
        cmd.Connection = cn;
        return cmd.ExecuteReader();
    }
    public static void AddInventory (string a1,int b2,string c3, string d4, decimal e5,int f6,string g7,string h8, string i9, string j10, string k11, string l12, string m13, string n14, string o15, string p16,string q17, string r18, string s19, string t20, out string message)
    {
 
        SqlConnection cn = null;
        try
        {
            cn = Setup_Connection();
            Add_Inventory(cn, a1,b2,c3,d4,e5,f6,g7,h8,i9,j10,k11,l12,m13,n14,o15,p16,q17,r18,s19,t20);  // Perform the query
            message = "";
        }
        catch (Exception ex)
        {
            message = " Error" + ex.Message;
        }
        finally
        {
            if (cn != null)
            {
                cn.Close();
            }
        }

    }
    public static void Add_Inventory(SqlConnection cn, string a1, int b2, string c3, string d4, decimal e5, int f6, string g7, string h8, string i9, string j10, string k11, string l12, string m13, string n14, string o15, string p16, string q17, string r18, string s19, string t20)
    {
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "INSERT INTO Inventory(Condition,Mileage,Price,Model,Make,Year,Engine,Transmision,PowerSteering,AntilockBrake,ServiceIndicator,FrontSideAB,ExteriorColor,Wheel,InteriorDesign,AudioSystem,Convenience,MaintenanceProgram,Warranty,ExtraPackage) VALUES (@con,@mile,@price,@model,@make,@year,@engine,@trans,@pst,@ABS,@si,@fab,@color,@wheel,@in,@as,@conve,@man,@war,@extra)";
        cmd.Parameters.AddWithValue("@con", a1); cmd.Parameters.AddWithValue("@mile", f6); cmd.Parameters.AddWithValue("@price", e5); cmd.Parameters.AddWithValue("@model", d4); cmd.Parameters.AddWithValue("@make", c3); cmd.Parameters.AddWithValue("@year", b2); cmd.Parameters.AddWithValue("@engine", h8); cmd.Parameters.AddWithValue("@trans", i9); cmd.Parameters.AddWithValue("@pst", t20);
        cmd.Parameters.AddWithValue("@ABS", j10); cmd.Parameters.AddWithValue("@si", k11); cmd.Parameters.AddWithValue("@fab", l12); cmd.Parameters.AddWithValue("@color", g7); cmd.Parameters.AddWithValue("@wheel", m13); cmd.Parameters.AddWithValue("@in", n14); cmd.Parameters.AddWithValue("@as", o15); cmd.Parameters.AddWithValue("@conve", p16); cmd.Parameters.AddWithValue("@man", q17); 
        cmd.Parameters.AddWithValue("@war", r18); cmd.Parameters.AddWithValue("@extra", s19);
        cmd.Connection = cn;
        cmd.ExecuteNonQuery();
    }

    
    public static Inventory GetModelInventory(out string message, string cond)
    {
        SqlDataReader rdr = null;
        SqlConnection cn = null;
        Inventory myinventory = null;

        try
        {
            cn = Setup_Connection();
            if (cond != "All" )
            {
                rdr = GetModel_Inventory(cond, cn);  // for New or Used condition only
            }
            else
            {
                rdr = GetAllModel_Inventory(cond, cn);  //for all conditions 
            }
            message = "";
            if (rdr.Read())
            {
                myinventory = new Inventory(rdr);
            }
            else
            {
                message = " Error in GetModelInventory.";
            }

        }
        catch (Exception ex)
        {
            message = " Error" + ex.Message;
        }
        finally
        {
            if (rdr != null)
            {
                rdr.Close();
            }

            if (cn != null)
            {
                cn.Close();
            }
        }
        return myinventory;
    }
    //get model for "New" or "Used" condition only
    public static SqlDataReader GetModel_Inventory(string condit,SqlConnection cn)
    {
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "SELECT DISTINCT * FROM Inventory WHERE Condition=@user";
        cmd.Parameters.AddWithValue("@user", condit);
        cmd.Connection = cn;
        return cmd.ExecuteReader();
    }
    //get model for "All" condition
    public static SqlDataReader GetAllModel_Inventory(string condit, SqlConnection cn)
    {
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "SELECT DISTINCT * FROM Inventory";

        cmd.Connection = cn;
        return cmd.ExecuteReader();
    }
    public static void UpdateInventory(string a1, int b2, string c3, string d4, decimal e5, int f6, string g7, string h8, string i9, string j10, string k11, string l12, string m13, string n14, string o15, string p16, string q17, string r18, string s19, string t20, out string message, int key)
    {

        SqlConnection cn = null;
        try
        {
            cn = Setup_Connection();
            Update_Inventory(cn, a1, b2, c3, d4, e5, f6, g7, h8, i9, j10, k11, l12, m13, n14, o15, p16, q17, r18, s19, t20, key);  // Perform the query
            message = "";
        }
        catch (Exception ex)
        {
            message = " Error" + ex.Message;
        }
        finally
        {
            if (cn != null)
            {
                cn.Close();
            }
        }
    }
    public static void Update_Inventory(SqlConnection cn, string a1, int b2, string c3, string d4, decimal e5, int f6, string g7, string h8, string i9, string j10, string k11, string l12, string m13, string n14, string o15, string p16, string q17, string r18, string s19, string t20, int key)
    {
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "UPDATE Inventory SET Condition=@con,Mileage=@mile,Price=@price,Model=@model,Make=@make,Year=@year,Engine=@engine,Transmision=@trans,PowerSteering=@pst,AntilockBrake=@ABS,ServiceIndicator=@si,FrontSideAB=@fab,ExteriorColor=@color,Wheel=@wheel,InteriorDesign=@in,AudioSystem=@as,Convenience=@conve,MaintenanceProgram=@man,Warranty=@war,ExtraPackage=@extra WHERE CarId=@car";
        cmd.Parameters.AddWithValue("@con", a1); cmd.Parameters.AddWithValue("@mile", f6); cmd.Parameters.AddWithValue("@price", e5); cmd.Parameters.AddWithValue("@model", d4); cmd.Parameters.AddWithValue("@make", c3); cmd.Parameters.AddWithValue("@year", b2); cmd.Parameters.AddWithValue("@engine", h8); cmd.Parameters.AddWithValue("@trans", i9); cmd.Parameters.AddWithValue("@pst", t20);
        cmd.Parameters.AddWithValue("@ABS", j10); cmd.Parameters.AddWithValue("@si", k11); cmd.Parameters.AddWithValue("@fab", l12); cmd.Parameters.AddWithValue("@color", g7); cmd.Parameters.AddWithValue("@wheel", m13); cmd.Parameters.AddWithValue("@in", n14); cmd.Parameters.AddWithValue("@as", o15); cmd.Parameters.AddWithValue("@conve", p16); cmd.Parameters.AddWithValue("@man", q17);
        cmd.Parameters.AddWithValue("@war", r18); cmd.Parameters.AddWithValue("@extra", s19); cmd.Parameters.AddWithValue("@car", key);
        cmd.Connection = cn;
        cmd.ExecuteNonQuery();
    }
    public static void DeleteInventory(out string message, int key_id)
    {

        SqlConnection cn = null;
        try
        {
            cn = Setup_Connection();
            Delete_Inventory(cn, key_id);  // Perform the query
            message = "";
        }
        catch (Exception ex)
        {
            message = " Error" + ex.Message;
        }
        finally
        {
            if (cn != null)
            {
                cn.Close();
            }
        }
    }
    public static void Delete_Inventory(SqlConnection cn, int key)
    {
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "DELETE FROM Inventory WHERE CarId=@con";
        cmd.Parameters.AddWithValue("@con",key);
        cmd.Connection = cn;
        cmd.ExecuteNonQuery();
    }
}