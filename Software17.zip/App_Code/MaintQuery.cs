﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;

/// <summary>
/// Summary description for MaintQuery
/// </summary>
public static class MaintQuery
{
	public static void CreateMaint(string veh,int mil, string date,string sch,string desc, out string message)
    {

        SqlConnection cn = null;
        try
        {
            cn = Setup_Connection();
            Create_Maint(cn,veh,mil, date,sch,desc);  // Perform the query
            message = "";
        }
        catch (Exception ex)
        {
            message = " Error" + ex.Message;
        }
        finally
        {
            if (cn != null)
            {
                cn.Close();
            }
        }

    }
    public static SqlConnection Setup_Connection()
    {
        String connection_string =
            WebConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;

        SqlConnection cn = new SqlConnection(connection_string);

        cn.Open();
        return cn;

    }
    public static void Create_Maint(SqlConnection cn, string veh,int mile,string date,string sch,string desc)
    {
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "INSERT INTO Maintenance(Veh_Id,Mileage,Date,Schedule,Description) VALUES (@veh,@mi,@da,@sch,@des)";
        cmd.Parameters.AddWithValue("@veh", veh); cmd.Parameters.AddWithValue("@mi", mile); 
        cmd.Parameters.AddWithValue("@da", date);
        cmd.Parameters.AddWithValue("@sch",sch); cmd.Parameters.AddWithValue("@des",desc);
        cmd.Connection = cn;
        cmd.ExecuteNonQuery();
    }
}