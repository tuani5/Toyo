﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Manufacturer
/// </summary>
public class Manufacturer
{
    private int man_key;
    private decimal _price;
    private string _model;
    private string _make;
    private int _year;
    private string _engine;
    private string _trans;
    private string _powsteer;
    private string _antibrake;
    private string _serind;
    private string _frontAB;
    private string _color;
    private string _wheel;
    private string _intdes;
    private string _audiosys;
    private string _conven;
    private string _maint;
    private string _warrant;
    private string _extra;
    private int _avail;


	public Manufacturer(SqlDataReader rdr)
	{
        man_key = (int)rdr["ManufactId"];
        _price = (decimal)rdr["Price"];
        _model = (string)rdr["Model"];
        _make = (string)rdr["Make"];
        _year = (int)rdr["Year"];
        _engine = (string)rdr["Engine"];
        _trans = (string)rdr["Transmision"];
        _powsteer = (string)rdr["PowerSteering"];
        _antibrake = (string)rdr["AntilockBrake"];
        _serind = (string)rdr["ServiceIndicator"];
        _frontAB = (string)rdr["FrontSideAB"];
        _color = (string)rdr["ExteriorColor"];
        _wheel = (string)rdr["Wheel"];
        _intdes = (string)rdr["InteriorDesign"];
        _audiosys = (string)rdr["AudioSystem"];
        _conven = (string)rdr["Convenience"];
        _maint = (string)rdr["MaintenanceProgram"];
        _warrant = (string)rdr["Warranty"];
        _extra = (string)rdr["ExtraPackage"];
        _avail = (int)rdr["Stock"];
	}
    public int GetManKey
    {
        get { return man_key; }
    }
    public decimal getPrice
    {
        get { return _price; }
    }
    public string getModel
    {
        get { return _model; }
    }
    public string getMake
    {
        get { return _make; }
    }
    public int getYear
    {
        get { return _year; }
    }
    public string getEngine
    {
        get { return _engine; }
    }
    public string getTrans
    {
        get { return _trans; }
    }
    public string getPowerSteering
    {
        get { return _powsteer; }
    }
    public string getAntilockBr
    {
        get { return _antibrake; }
    }
    public string getSerInd
    {
        get { return _serind; }
    }
    public string getFrontSAB
    {
        get { return _frontAB; }
    }
    public string getColor
    {
        get { return _color; }
    }
    public string getWheel
    {
        get { return _wheel; }
    }
    public string getIntDes
    {
        get { return _intdes; }
    }
    public string getAudSys
    {
        get { return _audiosys; }
    }
    public string getConve
    {
        get { return _conven; }
    }
    public string getMain
    {
        get { return _maint; }
    }
    public string getWarranty
    {
        get { return _warrant; }
    }
    public string getExtra
    {
        get { return _extra; }
    }
    public int GetManAvail
    {
        get { return _avail; }
    }
 
}