﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;

/// <summary>
/// Summary description for SaleQuery
/// </summary>
public static class SaleQuery
{
    public static Sale GetSale(int keyId,out string message)
	{
        SqlDataReader rdr = null;
        SqlConnection cn = null;
        Sale xsale = null;

        try
        {
            cn = Setup_Connection();
            rdr = Get_Sale(cn, keyId);  // Perform the query
            message = "";
            if (rdr.Read())
            {
                xsale = new Sale(rdr);
            }
            else
            {
                message = " Error in Sale.";
            }

        }
        catch (Exception ex)
        {
            message = " Error" + ex.Message;
        }
        finally
        {
            if (rdr != null)
            {
                rdr.Close();
            }

            if (cn != null)
            {
                cn.Close();
            }
        }
        return xsale;
	}
    public static SqlConnection Setup_Connection()
    {
        String connection_string =
            WebConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;

        SqlConnection cn = new SqlConnection(connection_string);

        cn.Open();
        return cn;

    }

    public static SqlDataReader Get_Sale(SqlConnection cn, int _keyId)
    {
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "SELECT * FROM Sale WHERE SaleId=@user";
        cmd.Parameters.AddWithValue("@user", _keyId);
        cmd.Connection = cn;
        return cmd.ExecuteReader();
    }
    public static void CreateSale(string a1, string b2, string c3, string d4, string e5, string f6, string g7, string h8, decimal i9, string j10,string ma, string wa, out string message)
    {

        SqlConnection cn = null;
        try
        {
            cn = Setup_Connection();
            Create_Sale(cn, a1, b2, c3, d4, e5, f6, g7, h8, i9, j10,ma,wa);  // Perform the query
            message = "";
        }
        catch (Exception ex)
        {
            message = " Error" + ex.Message;
        }
        finally
        {
            if (cn != null)
            {
                cn.Close();
            }
        }

    }
    public static void Create_Sale(SqlConnection cn, string a1, string b2, string c3, string d4, string e5, string f6, string g7, string h8, decimal i9, string j10, string ma, string wa)
    {
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "INSERT INTO Sale(CustomerId,Last_Name,First_Name,VId,Make,Model,Year,Date,Price,UserId,Maint_Prog,Warrent_Prog) VALUES (@con,@mile,@price,@model,@make,@year,@engine,@trans,@pst,@ABS,@Ma,@Wa)";
        cmd.Parameters.AddWithValue("@con", a1); cmd.Parameters.AddWithValue("@mile", b2); cmd.Parameters.AddWithValue("@price", c3); cmd.Parameters.AddWithValue("@model", d4); cmd.Parameters.AddWithValue("@make", e5); cmd.Parameters.AddWithValue("@year", f6); cmd.Parameters.AddWithValue("@engine", g7); cmd.Parameters.AddWithValue("@trans", h8); cmd.Parameters.AddWithValue("@pst", i9);
        cmd.Parameters.AddWithValue("@ABS", j10); cmd.Parameters.AddWithValue("@Ma", ma); cmd.Parameters.AddWithValue("@Wa", wa);
        cmd.Connection = cn;
        cmd.ExecuteNonQuery();
    }
}