﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;

/// <summary>
/// Summary description for ManufactQuery
/// </summary>
public static class ManufactQuery
{
    public static Manufacturer GetManufact(int _key, out string message)
    {
        SqlDataReader rdr = null;
        SqlConnection cn = null;
        Manufacturer mfr = null;

        try
        {
            cn = Setup_Connection();
            rdr = Get_Manufact(cn, _key);  // Perform the query
            message = "";
            if (rdr.Read())
            {
                mfr = new Manufacturer(rdr);
            }
            else
            {
                message = " Error in Manufacturer.";
            }

        }
        catch (Exception ex)
        {
            message = " Error" + ex.Message;
        }
        finally
        {
            if (rdr != null)
            {
                rdr.Close();
            }

            if (cn != null)
            {
                cn.Close();
            }
        }
        return mfr;
    }

    public static SqlConnection Setup_Connection()
    {
        String connection_string =
            WebConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;

        SqlConnection cn = new SqlConnection(connection_string);

        cn.Open();
        return cn;

    }

    public static SqlDataReader Get_Manufact(SqlConnection cn, int search)
    {
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "SELECT * FROM Manufacturer WHERE ManufactId=@user";
        cmd.Parameters.AddWithValue("@user", search);
        cmd.Connection = cn;
        return cmd.ExecuteReader();
    }
}