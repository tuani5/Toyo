﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;

/// <summary>
/// Summary description for BuyQuery
/// </summary>
public static class BuyQuery
{
    public static Buy GetBuy(int user_key, out string message)
	{
        SqlDataReader rdr = null;
        SqlConnection cn = null;
        Buy mua = null;

        try
        {
            cn = Setup_Connection();
            rdr = Get_Buy(cn, user_key);  // Perform the query
            message = "";
            if (rdr.Read())
            {
                mua = new Buy(rdr);
            }
            else
            {
                message = " Error in Buy.";
            }

        }
        catch (Exception ex)
        {
            message = " Error" + ex.Message;
        }
        finally
        {
            if (rdr != null)
            {
                rdr.Close();
            }

            if (cn != null)
            {
                cn.Close();
            }
        }
        return mua;
    }

    public static SqlConnection Setup_Connection()
    {
        String connection_string =
            WebConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;

        SqlConnection cn = new SqlConnection(connection_string);

        cn.Open();
        return cn;

    }

    public static SqlDataReader Get_Buy(SqlConnection cn, int search)
    {
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "SELECT * FROM FactoryOrder WHERE Order_No=@user";
        cmd.Parameters.AddWithValue("@user", search);
        cmd.Connection = cn;
        return cmd.ExecuteReader();
    }
    public static void CreateOrder(decimal a1, string b2, string c3, int d4, string e5, string f6, string g7, string h8, string i9, string j10, string k11, string l12, string m13, string n14, string o15, string p16, string q17, string r18, out string message)
    {

        SqlConnection cn = null;
        try
        {
            cn = Setup_Connection();
            Create_Order(cn, a1, b2, c3, d4, e5, f6, g7, h8, i9, j10, k11, l12, m13, n14, o15, p16, q17, r18);  // Perform the query
            message = "";
        }
        catch (Exception ex)
        {
            message = " Error" + ex.Message;
        }
        finally
        {
            if (cn != null)
            {
                cn.Close();
            }
        }

    }
  
    public static void Create_Order(SqlConnection cn, decimal a1, string b2, string c3, int d4, string e5, string f6, string g7, string h8, string i9, string j10, string k11, string l12, string m13, string n14, string o15, string p16, string q17, string r18)
    {
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "INSERT INTO FactoryOrder(Price,Model,Make,Year,Engine,Transmision,PowerSteering,AntilockBrake,ServiceIndicator,FrontSideAB,ExteriorColor,Wheel,InteriorDesign,AudioSystem,Convenience,ExtraPackage,CustomerId,Delivery) VALUES (@con,@mile,@price,@model,@make,@year,@engine,@trans,@pst,@ABS,@si,@fab,@color,@wheel,@in,@as,@conve,@man)";
        cmd.Parameters.AddWithValue("@con", a1); cmd.Parameters.AddWithValue("@mile", b2); cmd.Parameters.AddWithValue("@price", c3); cmd.Parameters.AddWithValue("@model", d4); cmd.Parameters.AddWithValue("@make", e5); cmd.Parameters.AddWithValue("@year", f6); cmd.Parameters.AddWithValue("@engine", g7); cmd.Parameters.AddWithValue("@trans", h8);
        cmd.Parameters.AddWithValue("@pst", i9); cmd.Parameters.AddWithValue("@ABS", j10); cmd.Parameters.AddWithValue("@si", k11); cmd.Parameters.AddWithValue("@fab", l12); cmd.Parameters.AddWithValue("@color", m13); cmd.Parameters.AddWithValue("@wheel", n14); cmd.Parameters.AddWithValue("@in", o15); cmd.Parameters.AddWithValue("@as", p16); cmd.Parameters.AddWithValue("@conve", q17);
        cmd.Parameters.AddWithValue("@man", r18);
        cmd.Connection = cn;
        cmd.ExecuteNonQuery();
    }
}