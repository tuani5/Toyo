﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Sale
/// </summary>
public class Sale
{
    private int _saleId;
    private string _custId;
    private string last;
    private string first;
    private string _vid;
    private string _make;
    private string _model;
    private string _year;
    private string _date;
    private decimal _price;
    private string _user;
	public Sale(SqlDataReader rdr)
	{
        _saleId = (int)rdr["SaleId"];
        _custId = (string)rdr["CustomerId"];
        last = (string)rdr["Last_Name"];
        first = (string)rdr["First_Name"];
        _vid = (string)rdr["VId"];
        _make = (string)rdr["Make"];
        _model = (string)rdr["Model"];
        _year = (string)rdr["Year"];
        _date = (string)rdr["Date"];
        _price = (decimal)rdr["Price"];
        _user = (string)rdr["UserId"];
	}
    public string getDate
    {
        get { return _date; }
    }
    public int GetSaleId
    {
        get { return _saleId; }
    }
}